cor_monde=[0 0 0
    0 5 0
    0 10 0
    0 15 0
    35 0 0 
    35 5 0
    35 10 0 
    35 15 0];
cor_monde1=[0 0 0
    0 5 0
    0 10 0
    0 15 0
    35 0 0 
    35 5 0
    35 10 0 
    35 15 0];
m=[cor_monde;cor_monde1];
disp(m);
a=[1 2 3 4 5 6 7 8 9]';
disp(a);
a=reshape(a,3,3)';
disp(a);